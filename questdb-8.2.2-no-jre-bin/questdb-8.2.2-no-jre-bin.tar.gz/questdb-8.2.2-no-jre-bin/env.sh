#!/usr/bin/env bash
export JAVA_MAIN="io.questdb/io.questdb.ServerMain"
